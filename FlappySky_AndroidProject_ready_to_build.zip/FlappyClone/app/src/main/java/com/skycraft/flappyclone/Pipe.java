package com.skycraft.flappyclone;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.RectF;

public class Pipe {

    public float x;
    public float gapY;       // center of the gap
    public float gapHeight;
    public float width;
    public boolean scored = false;

    private final float screenHeight;
    private Bitmap pipeBitmap;

    public Pipe(float x, float gapY, float gapHeight, float width, float screenHeight) {
        this.x = x;
        this.gapY = gapY;
        this.gapHeight = gapHeight;
        this.width = width;
        this.screenHeight = screenHeight;
    }

    public void setBitmap(Bitmap bmp) {
        this.pipeBitmap = bmp;
    }

    public void update(float speed) {
        x -= speed;
    }

    public boolean isOffScreen() {
        return x + width < 0;
    }

    public RectF getTopHitbox() {
        return new RectF(x, 0, x + width, gapY - gapHeight / 2f);
    }

    public RectF getBottomHitbox() {
        return new RectF(x, gapY + gapHeight / 2f, x + width, screenHeight);
    }

    public void draw(Canvas canvas) {
        if (pipeBitmap == null) return;

        float topPipeBottom = gapY - gapHeight / 2f;
        float bottomPipeTop = gapY + gapHeight / 2f;

        // Bottom pipe (drawn normally, scaled to fit width)
        Matrix bottomMatrix = new Matrix();
        float scaleX = width / pipeBitmap.getWidth();
        bottomMatrix.postScale(scaleX, scaleX);
        bottomMatrix.postTranslate(x, bottomPipeTop);
        canvas.save();
        canvas.clipRect(x, bottomPipeTop, x + width, screenHeight);
        // Tile vertically if needed
        float bmpScaledHeight = pipeBitmap.getHeight() * scaleX;
        float drawY = bottomPipeTop;
        while (drawY < screenHeight) {
            Matrix m = new Matrix();
            m.postScale(scaleX, scaleX);
            m.postTranslate(x, drawY);
            canvas.drawBitmap(pipeBitmap, m, null);
            drawY += bmpScaledHeight;
        }
        canvas.restore();

        // Top pipe (flipped vertically)
        canvas.save();
        canvas.clipRect(x, 0, x + width, topPipeBottom);
        drawY = topPipeBottom - bmpScaledHeight;
        while (drawY + bmpScaledHeight > 0) {
            Matrix m = new Matrix();
            m.postScale(scaleX, -scaleX);
            m.postTranslate(x, drawY + bmpScaledHeight);
            canvas.drawBitmap(pipeBitmap, m, null);
            drawY -= bmpScaledHeight;
        }
        canvas.restore();
    }
}
