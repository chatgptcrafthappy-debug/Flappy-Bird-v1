package com.skycraft.flappyclone;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.RectF;

public class Bird {

    public float x, y;
    public float width, height;
    private float velocity = 0f;
    private final float gravity;
    private final float flapStrength;
    private Bitmap[] frames;
    private int frameIndex = 0;
    private int frameTick = 0;
    public float rotation = 0f;

    public Bird(float x, float y, float width, float height, float gravity, float flapStrength) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.gravity = gravity;
        this.flapStrength = flapStrength;
    }

    public void setFrames(Bitmap[] frames) {
        this.frames = frames;
    }

    public void flap() {
        velocity = flapStrength;
    }

    public void update() {
        velocity += gravity;
        y += velocity;

        // rotation based on velocity: nose up when flapping, nose down when falling
        rotation = Math.max(-25f, Math.min(90f, velocity * 4f));

        frameTick++;
        if (frameTick > 4) {
            frameTick = 0;
            if (frames != null && frames.length > 0) {
                frameIndex = (frameIndex + 1) % frames.length;
            }
        }
    }

    public RectF getHitbox() {
        // Slightly smaller hitbox than sprite for fairer collisions
        float padX = width * 0.15f;
        float padY = height * 0.15f;
        return new RectF(x + padX, y + padY, x + width - padX, y + height - padY);
    }

    public void draw(Canvas canvas) {
        if (frames == null || frames.length == 0) return;
        Bitmap bmp = frames[frameIndex];

        Matrix matrix = new Matrix();
        matrix.postScale(width / bmp.getWidth(), height / bmp.getHeight());
        matrix.postRotate(rotation, (width / 2f), (height / 2f));
        matrix.postTranslate(x, y);

        canvas.drawBitmap(bmp, matrix, null);
    }

    public void reset(float startX, float startY) {
        x = startX;
        y = startY;
        velocity = 0f;
        rotation = 0f;
    }
}
