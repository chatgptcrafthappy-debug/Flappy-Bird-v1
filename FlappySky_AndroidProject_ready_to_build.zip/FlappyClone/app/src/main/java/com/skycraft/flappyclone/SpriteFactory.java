package com.skycraft.flappyclone;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;

/**
 * Generates all pixel-art style sprites procedurally so the game
 * ships with zero external image dependencies.
 */
public class SpriteFactory {

    // Classic Flappy-style palette
    private static final int BODY_YELLOW = Color.rgb(0xF7, 0xD0, 0x2C);
    private static final int BODY_YELLOW_DARK = Color.rgb(0xE0, 0xA9, 0x1A);
    private static final int WING_WHITE = Color.rgb(0xFF, 0xFF, 0xFF);
    private static final int BEAK_ORANGE = Color.rgb(0xF2, 0x7A, 0x1E);
    private static final int BEAK_ORANGE_DARK = Color.rgb(0xC9, 0x5A, 0x0E);
    private static final int EYE_WHITE = Color.WHITE;
    private static final int OUTLINE = Color.rgb(0x3B, 0x2A, 0x1A);

    /** Builds 3 bird frames (wing up, mid, down) at pixel-art scale. */
    public static Bitmap[] buildBirdFrames(int size) {
        Bitmap[] frames = new Bitmap[3];
        frames[0] = buildBirdFrame(size, -6);
        frames[1] = buildBirdFrame(size, 0);
        frames[2] = buildBirdFrame(size, 6);
        return frames;
    }

    private static Bitmap buildBirdFrame(int size, int wingOffset) {
        int grid = 16; // 16x16 pixel-art grid, scaled up
        int px = size / grid;
        Bitmap bmp = Bitmap.createBitmap(grid * px, grid * px, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint();
        p.setStyle(Paint.Style.FILL);

        // Body (rounded blob)
        p.setColor(BODY_YELLOW);
        drawPixelOval(c, p, px, 2, 3, 12, 11);

        // Belly shade
        p.setColor(BODY_YELLOW_DARK);
        drawPixelOval(c, p, px, 3, 8, 9, 6);

        // Wing
        p.setColor(WING_WHITE);
        int wingY = 7 + (wingOffset / (px == 0 ? 1 : px / 2 == 0 ? 1 : 1));
        drawPixelRect(c, p, px, 3, 6 + (wingOffset > 0 ? 1 : wingOffset < 0 ? -1 : 0), 6, 4);

        // Eye
        p.setColor(EYE_WHITE);
        drawPixelRect(c, p, px, 10, 3, 3, 3);
        p.setColor(OUTLINE);
        drawPixelRect(c, p, px, 12, 4, 1, 1);

        // Beak
        p.setColor(BEAK_ORANGE);
        drawPixelRect(c, p, px, 13, 6, 3, 2);
        p.setColor(BEAK_ORANGE_DARK);
        drawPixelRect(c, p, px, 13, 8, 3, 1);

        // Outline (simple silhouette pass for readability)
        p.setColor(OUTLINE);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(1, px / 4f));
        RectF bodyRect = new RectF(2 * px, 3 * px, 14 * px, 14 * px);
        c.drawOval(bodyRect, p);

        return bmp;
    }

    private static void drawPixelRect(Canvas c, Paint p, int px, int gx, int gy, int gw, int gh) {
        c.drawRect(gx * px, gy * px, (gx + gw) * px, (gy + gh) * px, p);
    }

    private static void drawPixelOval(Canvas c, Paint p, int px, int gx, int gy, int gw, int gh) {
        c.drawOval(new RectF(gx * px, gy * px, (gx + gw) * px, (gy + gh) * px), p);
    }

    /** Builds a repeatable pipe segment texture (green, Mario-pipe style). */
    public static Bitmap buildPipeSegment(int width, int height) {
        Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint();

        int green = Color.rgb(0x5E, 0xC6, 0x37);
        int greenDark = Color.rgb(0x3F, 0x9B, 0x21);
        int greenLight = Color.rgb(0x8B, 0xE0, 0x63);
        int outline = Color.rgb(0x2A, 0x54, 0x18);

        p.setColor(green);
        c.drawRect(0, 0, width, height, p);

        // Left highlight stripe
        p.setColor(greenLight);
        c.drawRect(0, 0, width * 0.18f, height, p);

        // Right shadow stripe
        p.setColor(greenDark);
        c.drawRect(width * 0.82f, 0, width, height, p);

        // Outline
        p.setColor(outline);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(2, width * 0.04f));
        c.drawRect(1, 1, width - 1, height - 1, p);

        return bmp;
    }

    /** Simple ground / grass tile. */
    public static Bitmap buildGroundTile(int width, int height) {
        Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint();

        int dirt = Color.rgb(0xDE, 0xD3, 0x95);
        int grass = Color.rgb(0x7B, 0xD8, 0x3E);
        int grassDark = Color.rgb(0x5C, 0xB8, 0x2A);

        p.setColor(dirt);
        c.drawRect(0, height * 0.25f, width, height, p);

        p.setColor(grass);
        c.drawRect(0, 0, width, height * 0.3f, p);

        p.setColor(grassDark);
        for (int i = 0; i < width; i += (int) (width * 0.08f)) {
            c.drawRect(i, height * 0.2f, i + width * 0.04f, height * 0.3f, p);
        }

        return bmp;
    }

    /** Sky background with soft gradient + simple clouds. */
    public static Bitmap buildBackground(int width, int height) {
        Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint();

        int top = Color.rgb(0x6E, 0xC6, 0xF2);
        int bottom = Color.rgb(0xBE, 0xEA, 0xF5);
        p.setShader(new LinearGradient(0, 0, 0, height, top, bottom, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, width, height, p);
        p.setShader(null);

        // Clouds
        p.setColor(Color.argb(180, 255, 255, 255));
        drawCloud(c, p, width * 0.2f, height * 0.18f, width * 0.12f);
        drawCloud(c, p, width * 0.65f, height * 0.28f, width * 0.09f);
        drawCloud(c, p, width * 0.42f, height * 0.12f, width * 0.07f);

        return bmp;
    }

    private static void drawCloud(Canvas c, Paint p, float cx, float cy, float r) {
        c.drawCircle(cx, cy, r, p);
        c.drawCircle(cx + r * 0.8f, cy + r * 0.2f, r * 0.7f, p);
        c.drawCircle(cx - r * 0.8f, cy + r * 0.2f, r * 0.7f, p);
    }

    /** App launcher icon: classic yellow pixel bird on sky-blue rounded background. */
    public static Bitmap buildAppIcon(int size) {
        Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint();
        p.setAntiAlias(false); // keep crisp pixel edges

        // Background
        int skyTop = Color.rgb(0x4E, 0xC0, 0xF2);
        int skyBottom = Color.rgb(0x9F, 0xE3, 0xF5);
        p.setShader(new LinearGradient(0, 0, 0, size, skyTop, skyBottom, Shader.TileMode.CLAMP));
        Path bg = new Path();
        float r = size * 0.18f;
        bg.addRoundRect(new RectF(0, 0, size, size), r, r, Path.Direction.CW);
        c.drawPath(bg, p);
        p.setShader(null);

        // Ground strip
        p.setColor(Color.rgb(0xDE, 0xD3, 0x95));
        c.drawRect(0, size * 0.82f, size, size, p);
        p.setColor(Color.rgb(0x7B, 0xD8, 0x3E));
        c.drawRect(0, size * 0.78f, size, size * 0.84f, p);

        // Bird centered, big
        Bitmap bird = buildBirdFrame(Math.round(size * 0.62f), 0);
        float bx = (size - bird.getWidth()) / 2f;
        float by = size * 0.16f;
        c.drawBitmap(bird, bx, by, null);

        return bmp;
    }
}
