package com.skycraft.flappyclone;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GameView extends SurfaceView implements SurfaceHolder.Callback, Runnable {

    private Thread gameThread;
    private volatile boolean running = false;
    private final SurfaceHolder holder;

    private int screenWidth, screenHeight;
    private boolean initialized = false;

    private enum State { READY, PLAYING, GAME_OVER }
    private State state = State.READY;

    private Bird bird;
    private final List<Pipe> pipes = new ArrayList<>();
    private final Random random = new Random();

    private Bitmap background;
    private Bitmap groundTile;
    private Bitmap pipeSegment;
    private Bitmap[] birdFrames;

    private float groundScrollX = 0f;
    private float pipeSpeed;
    private float pipeGapHeight;
    private float pipeSpacing;
    private float groundHeight;

    private int score = 0;
    private int bestScore = 0;
    private final SharedPreferences prefs;

    private final Paint textPaint = new Paint();
    private final Paint bigTextPaint = new Paint();
    private final Paint uiBgPaint = new Paint();

    public GameView(Context context) {
        super(context);
        holder = getHolder();
        holder.addCallback(this);
        setFocusable(true);

        prefs = context.getSharedPreferences("flappy_prefs", Context.MODE_PRIVATE);
        bestScore = prefs.getInt("best_score", 0);

        textPaint.setColor(Color.WHITE);
        textPaint.setAntiAlias(true);
        textPaint.setFakeBoldText(true);
        textPaint.setShadowLayer(4f, 2f, 2f, Color.argb(160, 0, 0, 0));

        bigTextPaint.setColor(Color.WHITE);
        bigTextPaint.setAntiAlias(true);
        bigTextPaint.setFakeBoldText(true);
        bigTextPaint.setTextAlign(Paint.Align.CENTER);
        bigTextPaint.setShadowLayer(6f, 3f, 3f, Color.argb(180, 0, 0, 0));

        uiBgPaint.setColor(Color.argb(140, 0, 0, 0));
    }

    private void setupWorld(int w, int h) {
        screenWidth = w;
        screenHeight = h;

        groundHeight = h * 0.14f;
        background = SpriteFactory.buildBackground(w, h);

        int groundTileWidth = w / 2;
        groundTile = SpriteFactory.buildGroundTile(groundTileWidth, Math.round(groundHeight));

        float birdSize = w * 0.11f;
        birdFrames = SpriteFactory.buildBirdFrames(Math.round(birdSize));

        float pipeWidth = w * 0.16f;
        pipeSegment = SpriteFactory.buildPipeSegment(Math.round(pipeWidth), Math.round(pipeWidth * 1.2f));

        pipeGapHeight = h * 0.28f;
        pipeSpacing = w * 0.55f;
        pipeSpeed = w * 0.006f;

        bird = new Bird(w * 0.28f, h * 0.4f, birdSize, birdSize, h * 0.00095f, -h * 0.017f);
        bird.setFrames(birdFrames);

        initialized = true;
        resetGame();
    }

    private void resetGame() {
        pipes.clear();
        bird.reset(screenWidth * 0.28f, screenHeight * 0.4f);
        score = 0;
        groundScrollX = 0f;
        spawnInitialPipes();
        state = State.READY;
    }

    private void spawnInitialPipes() {
        float startX = screenWidth * 1.1f;
        for (int i = 0; i < 4; i++) {
            addPipe(startX + i * pipeSpacing);
        }
    }

    private void addPipe(float x) {
        float minCenter = screenHeight * 0.22f + pipeGapHeight / 2f;
        float maxCenter = screenHeight - groundHeight - screenHeight * 0.1f - pipeGapHeight / 2f;
        float gapY = minCenter + random.nextFloat() * Math.max(1f, (maxCenter - minCenter));
        Pipe pipe = new Pipe(x, gapY, pipeGapHeight, pipeSegment.getWidth(), screenHeight - groundHeight);
        pipe.setBitmap(pipeSegment);
        pipes.add(pipe);
    }

    // ---------- Surface lifecycle ----------

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        resume();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        if (!initialized) {
            setupWorld(width, height);
        }
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        pause();
    }

    public void resume() {
        if (running) return;
        running = true;
        gameThread = new Thread(this);
        gameThread.start();
    }

    public void pause() {
        running = false;
        if (gameThread != null) {
            try {
                gameThread.join();
            } catch (InterruptedException ignored) {
            }
            gameThread = null;
        }
    }

    // ---------- Game loop ----------

    @Override
    public void run() {
        final long targetFrameTimeMs = 16; // ~60 FPS
        while (running) {
            long frameStart = System.currentTimeMillis();

            if (initialized) {
                update();
                render();
            }

            long frameTime = System.currentTimeMillis() - frameStart;
            long sleepTime = targetFrameTimeMs - frameTime;
            if (sleepTime > 0) {
                try {
                    Thread.sleep(sleepTime);
                } catch (InterruptedException ignored) {
                }
            }
        }
    }

    private void update() {
        groundScrollX -= pipeSpeed;
        if (groundScrollX <= -groundTile.getWidth()) {
            groundScrollX += groundTile.getWidth();
        }

        if (state != State.PLAYING) return;

        bird.update();

        for (Pipe pipe : pipes) {
            pipe.update(pipeSpeed);
            if (!pipe.scored && pipe.x + pipe.width < bird.x) {
                pipe.scored = true;
                score++;
            }
        }

        if (!pipes.isEmpty() && pipes.get(0).isOffScreen()) {
            float lastX = pipes.get(pipes.size() - 1).x;
            pipes.remove(0);
            addPipe(lastX + pipeSpacing);
        }

        checkCollisions();
    }

    private void checkCollisions() {
        RectF birdBox = bird.getHitbox();

        if (bird.y <= 0) {
            bird.y = 0;
            endGame();
            return;
        }

        if (bird.y + bird.height >= screenHeight - groundHeight) {
            bird.y = screenHeight - groundHeight - bird.height;
            endGame();
            return;
        }

        for (Pipe pipe : pipes) {
            if (RectF.intersects(birdBox, pipe.getTopHitbox()) ||
                    RectF.intersects(birdBox, pipe.getBottomHitbox())) {
                endGame();
                return;
            }
        }
    }

    private void endGame() {
        if (state == State.GAME_OVER) return;
        state = State.GAME_OVER;
        if (score > bestScore) {
            bestScore = score;
            prefs.edit().putInt("best_score", bestScore).apply();
        }
    }

    // ---------- Rendering ----------

    private void render() {
        if (!holder.getSurface().isValid()) return;
        Canvas canvas = holder.lockCanvas();
        if (canvas == null) return;

        try {
            canvas.drawBitmap(background, 0, 0, null);

            for (Pipe pipe : pipes) {
                pipe.draw(canvas);
            }

            drawGround(canvas);

            bird.draw(canvas);

            drawUI(canvas);
        } finally {
            holder.unlockCanvasAndPost(canvas);
        }
    }

    private void drawGround(Canvas canvas) {
        float y = screenHeight - groundHeight;
        float x = groundScrollX;
        while (x < screenWidth) {
            canvas.drawBitmap(groundTile, x, y, null);
            x += groundTile.getWidth();
        }
    }

    private void drawUI(Canvas canvas) {
        textPaint.setTextSize(screenWidth * 0.07f);

        if (state == State.PLAYING || state == State.GAME_OVER) {
            String scoreText = String.valueOf(score);
            bigTextPaint.setTextSize(screenWidth * 0.12f);
            canvas.drawText(scoreText, screenWidth / 2f, screenHeight * 0.12f, bigTextPaint);
        }

        if (state == State.READY) {
            bigTextPaint.setTextSize(screenWidth * 0.09f);
            canvas.drawText("FLAPPY SKY", screenWidth / 2f, screenHeight * 0.28f, bigTextPaint);
            bigTextPaint.setTextSize(screenWidth * 0.05f);
            canvas.drawText("Tap to start", screenWidth / 2f, screenHeight * 0.36f, bigTextPaint);
        }

        if (state == State.GAME_OVER) {
            float boxW = screenWidth * 0.7f;
            float boxH = screenHeight * 0.22f;
            float boxX = (screenWidth - boxW) / 2f;
            float boxY = screenHeight * 0.32f;
            canvas.drawRoundRect(new RectF(boxX, boxY, boxX + boxW, boxY + boxH), 24f, 24f, uiBgPaint);

            bigTextPaint.setTextSize(screenWidth * 0.07f);
            canvas.drawText("GAME OVER", screenWidth / 2f, boxY + boxH * 0.35f, bigTextPaint);

            bigTextPaint.setTextSize(screenWidth * 0.045f);
            canvas.drawText("Score: " + score + "   Best: " + bestScore,
                    screenWidth / 2f, boxY + boxH * 0.68f, bigTextPaint);

            bigTextPaint.setTextSize(screenWidth * 0.04f);
            canvas.drawText("Tap to retry", screenWidth / 2f, boxY + boxH * 0.92f, bigTextPaint);
        }
    }

    // ---------- Input ----------

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            handleTap();
            return true;
        }
        return super.onTouchEvent(event);
    }

    private void handleTap() {
        if (!initialized) return;
        switch (state) {
            case READY:
                state = State.PLAYING;
                bird.flap();
                break;
            case PLAYING:
                bird.flap();
                break;
            case GAME_OVER:
                resetGame();
                break;
        }
    }
}
